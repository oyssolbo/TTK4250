# set to false for speedup.
# Speedup will also occur if argument '-O' is given to python,
# as __debug__ then is False
DEBUG = False and __debug__
